import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Mi Reproductor',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> _recent = [];

  Future<void> _pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.video);
    final path = r?.files.single.path;
    if (path == null || !mounted) return;
    setState(() {
      _recent.remove(path);
      _recent.insert(0, path);
    });
    _open(path);
  }

  void _open(String path) => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PlayerPage(path: path)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Mi Reproductor')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _pick,
          icon: const Icon(Icons.video_library),
          label: const Text('Abrir video'),
        ),
        body: _recent.isEmpty
            ? const Center(child: Text('Toca "Abrir video" para empezar'))
            : ListView(
                children: [
                  for (final p in _recent)
                    ListTile(
                      leading: const Icon(Icons.play_circle_outline),
                      title: Text(p.split(Platform.pathSeparator).last),
                      onTap: () => _open(p),
                    ),
                ],
              ),
      );
}

class PlayerPage extends StatefulWidget {
  final String path;
  const PlayerPage({super.key, required this.path});

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final VideoPlayerController _c;
  bool _controls = true;
  bool _dragLeft = true;
  double _brightness = 0.5;
  String? _hud;
  double _speed = 1.0;
  BoxFit _fit = BoxFit.contain;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    WakelockPlus.enable();
    _c = VideoPlayerController.file(File(widget.path))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _c.play();
      });
    ScreenBrightness().current.then((v) => _brightness = v).catchError((_) {});
  }

  @override
  void dispose() {
    _c.dispose();
    WakelockPlus.disable();
    ScreenBrightness().resetScreenBrightness().catchError((_) {});
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _flash(String text) {
    setState(() => _hud = text);
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) setState(() => _hud = null);
    });
  }

  void _seekBy(int seconds) {
    final v = _c.value;
    var t = v.position + Duration(seconds: seconds);
    if (t < Duration.zero) t = Duration.zero;
    if (t > v.duration) t = v.duration;
    _c.seekTo(t);
    _flash(seconds > 0 ? '+${seconds}s' : '${seconds}s');
  }

  void _onVertical(DragUpdateDetails d) {
    final delta = -d.delta.dy / 250;
    if (_dragLeft) {
      _brightness = (_brightness + delta).clamp(0.0, 1.0);
      ScreenBrightness().setScreenBrightness(_brightness).catchError((_) {});
      _flash('Brillo ${(_brightness * 100).round()}%');
    } else {
      final vol = (_c.value.volume + delta).clamp(0.0, 1.0);
      _c.setVolume(vol);
      _flash('Volumen ${(vol * 100).round()}%');
    }
  }

  Future<void> _loadSubtitles() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['srt'],
    );
    final p = r?.files.single.path;
    if (p == null) return;
    final text = await File(p).readAsString();
    await _c.setClosedCaptionFile(Future.value(SubRipCaptionFile(text)));
    _flash('Subtítulos cargados');
  }

  String _fmt(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = two(d.inMinutes.remainder(60));
    final s = two(d.inSeconds.remainder(60));
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    if (!_c.value.isInitialized) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _controls = !_controls),
        onDoubleTapDown: (d) =>
            _seekBy(d.localPosition.dx < width / 2 ? -10 : 10),
        onDoubleTap: () {},
        onVerticalDragStart: (d) => _dragLeft = d.localPosition.dx < width / 2,
        onVerticalDragUpdate: _onVertical,
        child: Stack(
          fit: StackFit.expand,
          children: [
            FittedBox(
              fit: _fit,
              child: SizedBox(
                width: _c.value.size.width,
                height: _c.value.size.height,
                child: VideoPlayer(_c),
              ),
            ),
            ValueListenableBuilder<VideoPlayerValue>(
              valueListenable: _c,
              builder: (_, v, __) => Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: EdgeInsets.only(bottom: _controls ? 90 : 24),
                  child: v.caption.text.isEmpty
                      ? const SizedBox.shrink()
                      : Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          color: Colors.black54,
                          child: Text(v.caption.text,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 18)),
                        ),
                ),
              ),
            ),
            if (_hud != null)
              Center(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(8)),
                  child: Text(_hud!, style: const TextStyle(fontSize: 20)),
                ),
              ),
            if (_controls) _buildControls(),
          ],
        ),
      ),
    );
  }

  Widget _buildControls() => Container(
        color: Colors.black38,
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                Expanded(
                  child: Text(widget.path.split(Platform.pathSeparator).last,
                      overflow: TextOverflow.ellipsis),
                ),
                IconButton(
                  icon: const Icon(Icons.subtitles),
                  tooltip: 'Subtítulos (.srt)',
                  onPressed: _loadSubtitles,
                ),
                PopupMenuButton<double>(
                  icon: const Icon(Icons.speed),
                  tooltip: 'Velocidad',
                  initialValue: _speed,
                  onSelected: (s) {
                    setState(() => _speed = s);
                    _c.setPlaybackSpeed(s);
                  },
                  itemBuilder: (_) => [
                    for (final s in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                      PopupMenuItem(value: s, child: Text('${s}x')),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.aspect_ratio),
                  tooltip: 'Ajuste de pantalla',
                  onPressed: () => setState(() {
                    _fit = _fit == BoxFit.contain
                        ? BoxFit.cover
                        : _fit == BoxFit.cover
                            ? BoxFit.fill
                            : BoxFit.contain;
                  }),
                ),
              ],
            ),
            const Spacer(),
            ValueListenableBuilder<VideoPlayerValue>(
              valueListenable: _c,
              builder: (_, v, __) => Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: 36,
                        icon: const Icon(Icons.replay_10),
                        onPressed: () => _seekBy(-10),
                      ),
                      IconButton(
                        iconSize: 56,
                        icon: Icon(v.isPlaying
                            ? Icons.pause_circle_filled
                            : Icons.play_circle_filled),
                        onPressed: () =>
                            v.isPlaying ? _c.pause() : _c.play(),
                      ),
                      IconButton(
                        iconSize: 36,
                        icon: const Icon(Icons.forward_10),
                        onPressed: () => _seekBy(10),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const SizedBox(width: 12),
                      Text(_fmt(v.position)),
                      Expanded(
                        child: Slider(
                          value: v.position.inMilliseconds
                              .clamp(0, v.duration.inMilliseconds)
                              .toDouble(),
                          max: v.duration.inMilliseconds.toDouble(),
                          onChanged: (x) =>
                              _c.seekTo(Duration(milliseconds: x.round())),
                        ),
                      ),
                      Text(_fmt(v.duration)),
                      const SizedBox(width: 12),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}
